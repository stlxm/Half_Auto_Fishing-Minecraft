Minecraft Java 26.2 - Fishing SE resource pack template

IMPORTANT: Add your own OGG Vorbis audio before enabling this pack.
Put your audio at assets/minecraft/sounds/custom/fishing_alert.ogg in the ZIP.
Do not simply rename an MP3 or WAV; convert the audio to OGG Vorbis.
Install the completed ZIP in %APPDATA%\.minecraft\resourcepacks and enable it in Minecraft > Resource Packs.
Sound event: entity.fishing_bobber.splash. This sound can also play when casting the bobber.
